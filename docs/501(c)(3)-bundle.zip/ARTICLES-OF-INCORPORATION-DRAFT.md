# ARTICLES OF INCORPORATION — DRAFT
## Secure Pride, Inc.
### North Carolina Nonprofit Corporation (Form N-01)
### DRAFT — For review before filing with NC Secretary of State

---

> **FILING INSTRUCTIONS:** When ready to file, transfer this content to the official
> NC Form N-01 available at sosnc.gov. File online or by mail with a $60 check
> payable to "NC Secretary of State." Attach Exhibit A and Exhibit B below.
> Do NOT file this markdown file — it is a working draft only.

---

## ARTICLES OF INCORPORATION
### Secure Pride, Inc.

Pursuant to Chapter 55A of the North Carolina General Statutes, the undersigned
incorporator hereby adopts the following Articles of Incorporation for the purpose
of forming a nonprofit corporation:

---

### Article I — Name

The name of the nonprofit corporation is:

**Secure Pride, Inc.**

---

### Article II — Charitable Corporation Status

This corporation is a charitable or religious corporation as defined in
N.C.G.S. § 55A-1-40(4).

---

### Article III — Registered Agent and Registered Office

**3.1 Registered Agent:**
[FULL LEGAL NAME OF REGISTERED AGENT]
<!-- INSERT: Your name (Mazze LeCzzare Frazer) or a registered agent service -->

**3.2 Street Address of Registered Office:**
[STREET ADDRESS]
[CITY], NC  [ZIP CODE]
[COUNTY] County

<!-- NOTE: Must be a physical NC address — no P.O. boxes. -->

---

### Article IV — Incorporator

The name and address of the incorporator is:

**Name:** [INCORPORATOR FULL LEGAL NAME]
**Address:** [STREET ADDRESS]
[CITY], NC [ZIP CODE]

<!-- For small orgs, the incorporator is typically the founding director. -->

---

### Article V — Members

This corporation shall have **no members** within the meaning of
Chapter 55A of the North Carolina General Statutes.

<!-- NOTE: "No members" means the board self-governs. This is standard for
     small nonprofits and simplifies governance. -->

---

### Article VI — Principal Office

The street address of the corporation's principal office is:

[STREET ADDRESS]
[CITY], NC [ZIP CODE]

---

### Exhibit A — Purpose and Exempt Status Language
*(Attach to Form N-01 in response to Question 8 — "Other Provisions")*
*(This language satisfies the IRS "organizational test" for 501(c)(3) status)*

---

**STATEMENT OF PURPOSE (Article VII)**

This corporation is organized and shall be operated exclusively for charitable
and educational purposes within the meaning of Section 501(c)(3) of the Internal
Revenue Code of 1986, as amended (the "Code"), including but not limited to:

(a) providing cybersecurity education, training, tools, and technical assistance
to LGBTQ+ organizations, community health clinics, small businesses, and other
community-serving entities that lack access to enterprise-level security resources;

(b) researching and developing open-source security tools, frameworks, and
educational resources designed to be culturally competent, accessible, and
privacy-preserving for underserved communities;

(c) building capacity within LGBTQ+-serving organizations to protect sensitive
personal data — including sexual orientation and gender identity information —
from unauthorized disclosure, breach, or misuse;

(d) educating community organizations, their staff, and leadership about
cybersecurity risks, data protection obligations, and digital safety practices;

and (e) engaging in any other charitable and educational activities consistent
with Section 501(c)(3) of the Code.

No part of the net earnings of this corporation shall inure to the benefit of,
or be distributable to, its directors, officers, members, or other private
persons, except that the corporation shall be authorized and empowered to pay
reasonable compensation for services rendered and to make payments and
distributions in furtherance of its exempt purposes.

No substantial part of the activities of this corporation shall be the carrying
on of propaganda or otherwise attempting to influence legislation, and the
corporation shall not participate in, or intervene in (including the publishing
or distribution of statements), any political campaign on behalf of or in
opposition to any candidate for public office.

Notwithstanding any other provision of these Articles, this corporation shall
not carry on any other activities not permitted to be carried on (a) by a
corporation exempt from federal income tax under Section 501(c)(3) of the Code,
or (b) by a corporation, contributions to which are deductible under
Section 170(c)(2) of the Code.

---

**STATEMENT ON DISSOLUTION (Article VIII)**

Upon the dissolution of this corporation, assets shall be distributed for one
or more exempt purposes within the meaning of Section 501(c)(3) of the Code,
or shall be distributed to the federal government, or to a state or local
government, for a public purpose. Any such assets not so disposed of shall be
disposed of by the Superior Court of the county in which the principal office
of the corporation is then located, exclusively for such purposes or to such
organization or organizations, as said Court shall determine, which are
organized and operated exclusively for such purposes.

---

**LIMITATION OF LIABILITY (Article IX)**

To the fullest extent permitted by Chapter 55A of the North Carolina General
Statutes, as amended from time to time, no director of this corporation shall
be personally liable for monetary damages for breach of duty as a director.

---

*(End of Exhibit A)*

---

### Certification

I, the undersigned incorporator, hereby declare that the facts stated above
are true and correct.

**Date:** ____________________

**Incorporator Signature:** ____________________

**Printed Name:** [INCORPORATOR FULL LEGAL NAME]

---

## CHECKLIST — Before Filing

- [ ] Legal name "Secure Pride, Inc." confirmed available at sosnc.gov name search
- [ ] EIN obtained from IRS (free, at irs.gov)
- [ ] Registered agent name and NC address inserted
- [ ] Incorporator name and address inserted
- [ ] Exhibit A reviewed by an attorney (recommended but not required)
- [ ] $60 filing fee check made out to "NC Secretary of State"
- [ ] Articles printed, signed, and scanned OR filed online at sosnc.gov

---

## FILING FEES & TIMELINE

| Method | Fee | Processing |
|--------|-----|-----------|
| Online (sosnc.gov) | $60 | 7–10 business days |
| Mail | $60 | 10–15 business days |
| Expedite (online) | $100 | 2–3 business days |

---

*This draft was prepared as a working document for Secure Pride, Inc. and does
not constitute legal advice. Review with a licensed NC attorney before filing
if possible — NC Pro Bono Resource Center (ncprobono.org) may offer free assistance.*
