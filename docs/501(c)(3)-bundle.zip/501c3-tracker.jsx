import { useState } from "react";

const PHASES = [
  {
    id: "pre",
    label: "Phase 0 — Do Today",
    subtitle: "No money required",
    color: "#2dd4bf",
    tasks: [
      {
        id: "name-check",
        title: "NC name availability check",
        detail: "Search 'Secure Pride' at sosnc.gov/online_services/search/by_name. Confirm no conflicts. Also check USPTO TESS for trademark conflicts.",
        link: "https://www.sosnc.gov/online_services/search/by_name",
        linkLabel: "NC SOS Name Search",
        status: "todo",
        doNow: true,
      },
      {
        id: "ein",
        title: "Apply for EIN (Employer ID Number)",
        detail: "Free, online, instant. Required before any IRS filing. Use your personal address as principal office for now. Takes ~10 minutes.",
        link: "https://www.irs.gov/businesses/small-businesses-self-employed/apply-for-an-employer-identification-number-ein-online",
        linkLabel: "IRS EIN Application",
        status: "todo",
        doNow: true,
      },
      {
        id: "articles-draft",
        title: "Draft Articles of Incorporation (NC Form N-01)",
        detail: "Template provided in this package. Must include: purpose clause (charitable/educational), dissolution clause, no-inurement clause, no-political-activity clause. Use IRS-approved language.",
        status: "todo",
        doNow: true,
      },
      {
        id: "bylaws-draft",
        title: "Draft Bylaws",
        detail: "Template provided. Covers: board structure, officer roles, meeting quorum, amendment procedures, fiscal year. Required for full Form 1023 (not 1023-EZ). Draft now regardless.",
        status: "todo",
        doNow: true,
      },
      {
        id: "coi-draft",
        title: "Draft Conflict of Interest Policy",
        detail: "Use IRS model COI policy (Publication 557 Appendix A). Required for 1023 filers. Critical for board credibility with institutional funders.",
        link: "https://www.irs.gov/pub/irs-pdf/p557.pdf",
        linkLabel: "IRS Pub 557",
        status: "todo",
        doNow: true,
      },
      {
        id: "board-identify",
        title: "Identify initial Board of Directors (≥3 members)",
        detail: "IRS requires at minimum 3 unrelated directors. They must be listed in the articles or bylaws. Choose people who understand the mission and are reliable for governance. No majority of board can be related by blood/marriage.",
        status: "todo",
        doNow: true,
      },
      {
        id: "ntee-code",
        title: "Select NTEE Code",
        detail: "Best candidates for Secure Pride: U41 (Computer Science) or R20 (Civil Rights for minorities). NTEE code is required on both 1023 and 1023-EZ. Affects grant discovery. Recommendation: U41.",
        link: "https://ntee.urban.org/",
        linkLabel: "NTEE Code Lookup",
        status: "todo",
        doNow: true,
      },
      {
        id: "form-choice",
        title: "Decide: Form 1023 vs. 1023-EZ",
        detail: "1023-EZ: $275 fee, 1–3 month review, minimal detail (bad for grant funders). Full 1023: $600 fee, 3–6 month review, full narrative (required for OTF, Mozilla MOSS, Gilead COMPASS credibility). Recommendation: Full 1023.",
        status: "todo",
        doNow: true,
      },
      {
        id: "registered-agent",
        title: "Designate NC Registered Agent",
        detail: "Must be a person or entity with a NC physical address (no P.O. boxes). Can be you (Mazze) at your Durham address, or a free/low-cost registered agent service. Required to file N-01.",
        status: "todo",
        doNow: true,
      },
    ],
  },
  {
    id: "formation",
    label: "Phase 1 — Incorporation",
    subtitle: "$60 NC filing fee required",
    color: "#fb923c",
    tasks: [
      {
        id: "nc-file",
        title: "File Articles of Incorporation with NC SOS",
        detail: "Submit Form N-01 online or by mail. $60 fee. Attach: purpose clause, dissolution clause, tax-exempt language (use NC SOS 'Tax Exempt Status Information' form). Processing: 1–2 weeks standard, faster with expedite fee.",
        link: "https://www.sosnc.gov/online_services/online_business_registration",
        linkLabel: "NC SOS Online Filing",
        status: "todo",
        doNow: false,
      },
      {
        id: "board-meeting",
        title: "Hold organizational board meeting",
        detail: "Formally install board of directors. Adopt bylaws. Adopt COI policy. Elect officers (President/Executive Director, Secretary, Treasurer). Record minutes — these become your foundational corporate record.",
        status: "todo",
        doNow: false,
      },
      {
        id: "bank-account",
        title: "Open nonprofit bank account",
        detail: "Requires: EIN, Articles of Incorporation (filed + stamped), board meeting minutes, resolution authorizing account. Many credit unions have free nonprofit accounts. Avoid banks with high minimum balance requirements.",
        status: "todo",
        doNow: false,
      },
      {
        id: "fiscal-transition",
        title: "Notify Open Collective of incorporation",
        detail: "If currently under fiscal sponsorship, coordinate transition timeline. You can maintain fiscal sponsor relationship until IRS determination letter arrives.",
        status: "todo",
        doNow: false,
      },
    ],
  },
  {
    id: "irs",
    label: "Phase 2 — IRS 501(c)(3) Application",
    subtitle: "$600 user fee (Form 1023) or $275 (1023-EZ)",
    color: "#a78bfa",
    tasks: [
      {
        id: "pay-gov-account",
        title: "Create Pay.gov account",
        detail: "All IRS exempt-org applications are filed through pay.gov. Create account before you're ready to file — verification takes a day or two.",
        link: "https://www.pay.gov",
        linkLabel: "Pay.gov",
        status: "todo",
        doNow: false,
      },
      {
        id: "narrative",
        title: "Write program narrative (Part IV of Form 1023)",
        detail: "The most important section. Describe: (1) past/present/planned activities, (2) who you serve, (3) how activities further exempt purposes. Be specific about LGBTQ+ org security services. Draft this now — it takes the most time.",
        status: "todo",
        doNow: true,
      },
      {
        id: "budget",
        title: "Prepare 3-year projected budget",
        detail: "Form 1023 Part IX requires projected revenue and expenses for 3 years if you've existed less than 1 year. Include: grants, donations, program revenue. Expenses: personnel, infrastructure, outreach.",
        status: "todo",
        doNow: false,
      },
      {
        id: "1023-submit",
        title: "Submit Form 1023 (or 1023-EZ) via Pay.gov",
        detail: "Attach: Articles of Incorporation (filed + stamped), Bylaws, COI Policy, narrative, budget. Submission triggers 3–6 month review clock. You'll receive an acknowledgment letter within 2 weeks.",
        status: "todo",
        doNow: false,
      },
      {
        id: "irs-response",
        title: "Respond to any IRS information requests",
        detail: "IRS may send a 'development letter' asking for clarification. Respond within the stated deadline (usually 30 days). Most requests are minor clarifications of the narrative.",
        status: "todo",
        doNow: false,
      },
      {
        id: "determination",
        title: "Receive IRS Determination Letter",
        detail: "The letter confirms 501(c)(3) status. It specifies your public charity classification (likely 509(a)(1) or (2)). This letter is what grantors, Apple, and donors need.",
        status: "todo",
        doNow: false,
      },
    ],
  },
  {
    id: "post",
    label: "Phase 3 — Post-Determination",
    subtitle: "After IRS letter arrives",
    color: "#4ade80",
    tasks: [
      {
        id: "nc-tax-exempt",
        title: "Apply for NC state tax exemption",
        detail: "Send Articles of Incorporation, Bylaws, and Federal Determination Letter to NC DOR. No fee. Exempts you from NC corporate income tax and franchise tax.",
        link: "https://www.ncdor.gov/taxes-forms/corporate-income-franchise-tax/nonprofit-corporate-tax-information",
        linkLabel: "NC DOR",
        status: "todo",
        doNow: false,
      },
      {
        id: "charitable-reg",
        title: "Register for NC charitable solicitations",
        detail: "NC requires registration with the Secretary of State before soliciting donations. File Form NC-478 with the NC SOS Charities Division. Annual renewal required.",
        status: "todo",
        doNow: false,
      },
      {
        id: "apple-waiver",
        title: "Apply for Apple Developer Program fee waiver",
        detail: "Use the IRS Determination Letter + Articles of Incorporation as proof of nonprofit status. Select 'Request fee waiver' during enrollment. Covers macOS notarization ($99/yr value).",
        link: "https://developer.apple.com/help/account/membership/fee-waivers/",
        linkLabel: "Apple Fee Waiver",
        status: "todo",
        doNow: false,
      },
      {
        id: "990-n",
        title: "File annual Form 990-N (e-Postcard)",
        detail: "If gross receipts ≤$50k, file Form 990-N. Free, online, takes 5 minutes. Due by the 15th day of the 5th month after your fiscal year ends. Missing 3 consecutive years = automatic revocation.",
        status: "todo",
        doNow: false,
      },
      {
        id: "grant-apps",
        title: "Begin grant applications",
        detail: "Now eligible: Open Technology Fund, Mozilla MOSS, Digital Defenders Partnership, Gilead COMPASS Initiative. Determination letter required by all. Most have rolling or semi-annual windows.",
        status: "todo",
        doNow: false,
      },
    ],
  },
];

const STATUS_CONFIG = {
  todo: { label: "To Do", color: "#64748b", bg: "rgba(100,116,139,0.12)" },
  inprogress: { label: "In Progress", color: "#fb923c", bg: "rgba(251,146,60,0.12)" },
  done: { label: "Done", color: "#4ade80", bg: "rgba(74,222,128,0.12)" },
  blocked: { label: "Blocked", color: "#f87171", bg: "rgba(248,113,113,0.12)" },
};

const COSTS = {
  "nc-file": "$60",
  "pay-gov-account": "free",
  "1023-submit": "$600",
  "ein": "free",
  "charitable-reg": "$0–200/yr",
  "apple-waiver": "$0 (waived)",
};

export default function App() {
  const [tasks, setTasks] = useState(() => {
    const init = {};
    PHASES.forEach(p => p.tasks.forEach(t => { init[t.id] = t.status; }));
    return init;
  });
  const [expandedTask, setExpandedTask] = useState(null);
  const [activePhase, setActivePhase] = useState("pre");

  const cycleStatus = (id) => {
    const order = ["todo", "inprogress", "done", "blocked"];
    setTasks(prev => {
      const current = prev[id];
      const next = order[(order.indexOf(current) + 1) % order.length];
      return { ...prev, [id]: next };
    });
  };

  const getPhaseProgress = (phase) => {
    const phaseTasks = phase.tasks;
    const done = phaseTasks.filter(t => tasks[t.id] === "done").length;
    return { done, total: phaseTasks.length, pct: Math.round((done / phaseTasks.length) * 100) };
  };

  const totalDone = Object.values(tasks).filter(v => v === "done").length;
  const totalTasks = Object.values(tasks).length;

  const currentPhase = PHASES.find(p => p.id === activePhase);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0d1117",
      color: "#e2e8f0",
      fontFamily: "'IBM Plex Mono', 'Courier New', monospace",
      padding: "0",
    }}>
      {/* Header */}
      <div style={{
        borderBottom: "1px solid #1e293b",
        padding: "28px 32px 20px",
        background: "#0d1117",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ fontSize: 10, color: "#4ade80", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: 4 }}>
              ◈ Secure Pride
            </div>
            <h1 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: "#f1f5f9", letterSpacing: "-0.02em" }}>
              501(c)(3) Formation Tracker
            </h1>
            <div style={{ fontSize: 11, color: "#64748b", marginTop: 4 }}>
              North Carolina · Form 1023 pathway · {totalDone}/{totalTasks} tasks complete
            </div>
          </div>
          {/* Global progress */}
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 28, fontWeight: 700, color: "#2dd4bf", lineHeight: 1 }}>
              {Math.round((totalDone / totalTasks) * 100)}%
            </div>
            <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>overall progress</div>
          </div>
        </div>

        {/* Master progress bar */}
        <div style={{ marginTop: 16, height: 3, background: "#1e293b", borderRadius: 2 }}>
          <div style={{
            height: "100%",
            width: `${(totalDone / totalTasks) * 100}%`,
            background: "linear-gradient(90deg, #2dd4bf, #4ade80)",
            borderRadius: 2,
            transition: "width 0.4s ease",
          }} />
        </div>
      </div>

      <div style={{ display: "flex", minHeight: "calc(100vh - 120px)" }}>
        {/* Phase sidebar */}
        <div style={{
          width: 200,
          borderRight: "1px solid #1e293b",
          padding: "20px 0",
          flexShrink: 0,
        }}>
          {PHASES.map(phase => {
            const prog = getPhaseProgress(phase);
            const isActive = activePhase === phase.id;
            return (
              <button
                key={phase.id}
                onClick={() => setActivePhase(phase.id)}
                style={{
                  width: "100%",
                  background: isActive ? "rgba(255,255,255,0.04)" : "transparent",
                  border: "none",
                  borderLeft: isActive ? `2px solid ${phase.color}` : "2px solid transparent",
                  padding: "14px 16px",
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "all 0.15s",
                }}
              >
                <div style={{ fontSize: 10, color: phase.color, letterSpacing: "0.1em", marginBottom: 2 }}>
                  {phase.label.split("—")[0].trim()}
                </div>
                <div style={{ fontSize: 11, color: isActive ? "#e2e8f0" : "#94a3b8", fontWeight: 500, lineHeight: 1.3 }}>
                  {phase.label.split("—")[1]?.trim()}
                </div>
                <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 6 }}>
                  <div style={{ flex: 1, height: 2, background: "#1e293b", borderRadius: 1 }}>
                    <div style={{
                      height: "100%",
                      width: `${prog.pct}%`,
                      background: phase.color,
                      borderRadius: 1,
                      transition: "width 0.4s",
                    }} />
                  </div>
                  <span style={{ fontSize: 9, color: "#64748b" }}>{prog.done}/{prog.total}</span>
                </div>
              </button>
            );
          })}

          {/* Cost summary */}
          <div style={{ margin: "20px 12px 0", padding: 12, background: "#111827", borderRadius: 6, border: "1px solid #1e293b" }}>
            <div style={{ fontSize: 9, color: "#64748b", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>Est. Filing Costs</div>
            <div style={{ fontSize: 11, color: "#94a3b8" }}>NC Articles: <span style={{ color: "#fb923c" }}>$60</span></div>
            <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 4 }}>Form 1023: <span style={{ color: "#fb923c" }}>$600</span></div>
            <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 4 }}>EIN: <span style={{ color: "#4ade80" }}>free</span></div>
            <div style={{ borderTop: "1px solid #1e293b", marginTop: 8, paddingTop: 8, fontSize: 11, color: "#e2e8f0", fontWeight: 600 }}>
              Total: <span style={{ color: "#fb923c" }}>~$660</span>
            </div>
          </div>
        </div>

        {/* Task list */}
        <div style={{ flex: 1, padding: "20px 24px", overflowY: "auto" }}>
          {/* Phase header */}
          <div style={{
            padding: "16px 20px",
            background: `linear-gradient(135deg, rgba(255,255,255,0.03) 0%, transparent 100%)`,
            border: `1px solid ${currentPhase.color}22`,
            borderRadius: 8,
            marginBottom: 20,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 10, color: currentPhase.color, letterSpacing: "0.15em", textTransform: "uppercase" }}>
                  {currentPhase.label}
                </div>
                <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 3 }}>{currentPhase.subtitle}</div>
              </div>
              {(() => {
                const prog = getPhaseProgress(currentPhase);
                return (
                  <div style={{ fontSize: 24, fontWeight: 700, color: currentPhase.color }}>
                    {prog.pct}%
                  </div>
                );
              })()}
            </div>
          </div>

          {/* Tasks */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {currentPhase.tasks.map(task => {
              const status = tasks[task.id];
              const sc = STATUS_CONFIG[status];
              const isExpanded = expandedTask === task.id;

              return (
                <div
                  key={task.id}
                  style={{
                    background: isExpanded ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.02)",
                    border: `1px solid ${isExpanded ? "#2d3748" : "#1e293b"}`,
                    borderRadius: 8,
                    overflow: "hidden",
                    transition: "all 0.2s",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 12,
                      padding: "12px 16px",
                      cursor: "pointer",
                    }}
                    onClick={() => setExpandedTask(isExpanded ? null : task.id)}
                  >
                    {/* Status toggle */}
                    <button
                      onClick={e => { e.stopPropagation(); cycleStatus(task.id); }}
                      title={`Status: ${sc.label} — click to cycle`}
                      style={{
                        flexShrink: 0,
                        width: 22,
                        height: 22,
                        borderRadius: "50%",
                        border: `2px solid ${sc.color}`,
                        background: status === "done" ? sc.color : "transparent",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 10,
                        color: status === "done" ? "#0d1117" : sc.color,
                      }}
                      aria-label={`Toggle status for ${task.title}`}
                    >
                      {status === "done" ? "✓" : status === "inprogress" ? "→" : status === "blocked" ? "!" : ""}
                    </button>

                    {/* Title */}
                    <div style={{ flex: 1 }}>
                      <div style={{
                        fontSize: 13,
                        color: status === "done" ? "#64748b" : "#e2e8f0",
                        textDecoration: status === "done" ? "line-through" : "none",
                        fontWeight: 500,
                      }}>
                        {task.title}
                        {task.doNow && status === "todo" && (
                          <span style={{
                            marginLeft: 8,
                            fontSize: 9,
                            color: "#2dd4bf",
                            border: "1px solid #2dd4bf44",
                            borderRadius: 3,
                            padding: "1px 5px",
                            letterSpacing: "0.08em",
                            verticalAlign: "middle",
                          }}>DO NOW</span>
                        )}
                      </div>
                    </div>

                    {/* Cost badge */}
                    {COSTS[task.id] && (
                      <span style={{
                        fontSize: 10,
                        color: COSTS[task.id] === "free" ? "#4ade80" : "#fb923c",
                        background: COSTS[task.id] === "free" ? "rgba(74,222,128,0.08)" : "rgba(251,146,60,0.08)",
                        border: `1px solid ${COSTS[task.id] === "free" ? "#4ade8022" : "#fb923c22"}`,
                        borderRadius: 4,
                        padding: "2px 7px",
                        flexShrink: 0,
                      }}>
                        {COSTS[task.id]}
                      </span>
                    )}

                    {/* Status pill */}
                    <span style={{
                      fontSize: 9,
                      color: sc.color,
                      background: sc.bg,
                      borderRadius: 4,
                      padding: "2px 7px",
                      letterSpacing: "0.08em",
                      textTransform: "uppercase",
                      flexShrink: 0,
                    }}>
                      {sc.label}
                    </span>

                    {/* Expand arrow */}
                    <span style={{ color: "#334155", fontSize: 10, transform: isExpanded ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}>
                      ▼
                    </span>
                  </div>

                  {/* Expanded detail */}
                  {isExpanded && (
                    <div style={{
                      padding: "0 16px 14px 50px",
                      borderTop: "1px solid #1e293b",
                      paddingTop: 12,
                    }}>
                      <p style={{ margin: "0 0 10px", fontSize: 12, color: "#94a3b8", lineHeight: 1.6 }}>
                        {task.detail}
                      </p>
                      {task.link && (
                        <a
                          href={task.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            fontSize: 11,
                            color: "#2dd4bf",
                            textDecoration: "none",
                            border: "1px solid #2dd4bf33",
                            borderRadius: 4,
                            padding: "4px 10px",
                            display: "inline-block",
                          }}
                        >
                          ↗ {task.linkLabel}
                        </a>
                      )}

                      {/* Status changer */}
                      <div style={{ marginTop: 12, display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {Object.entries(STATUS_CONFIG).map(([s, cfg]) => (
                          <button
                            key={s}
                            onClick={() => setTasks(prev => ({ ...prev, [task.id]: s }))}
                            style={{
                              fontSize: 9,
                              padding: "3px 9px",
                              borderRadius: 4,
                              border: `1px solid ${tasks[task.id] === s ? cfg.color : "#1e293b"}`,
                              background: tasks[task.id] === s ? cfg.bg : "transparent",
                              color: tasks[task.id] === s ? cfg.color : "#475569",
                              cursor: "pointer",
                              letterSpacing: "0.08em",
                              textTransform: "uppercase",
                            }}
                            aria-label={`Set status to ${cfg.label}`}
                          >
                            {cfg.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Phase navigation */}
          <div style={{ display: "flex", gap: 8, marginTop: 24, justifyContent: "space-between" }}>
            <button
              onClick={() => {
                const idx = PHASES.findIndex(p => p.id === activePhase);
                if (idx > 0) setActivePhase(PHASES[idx - 1].id);
              }}
              disabled={activePhase === PHASES[0].id}
              style={{
                padding: "8px 16px",
                background: "transparent",
                border: "1px solid #1e293b",
                borderRadius: 6,
                color: activePhase === PHASES[0].id ? "#334155" : "#94a3b8",
                cursor: activePhase === PHASES[0].id ? "not-allowed" : "pointer",
                fontSize: 11,
              }}
            >
              ← Previous phase
            </button>
            <button
              onClick={() => {
                const idx = PHASES.findIndex(p => p.id === activePhase);
                if (idx < PHASES.length - 1) setActivePhase(PHASES[idx + 1].id);
              }}
              disabled={activePhase === PHASES[PHASES.length - 1].id}
              style={{
                padding: "8px 16px",
                background: "transparent",
                border: "1px solid #1e293b",
                borderRadius: 6,
                color: activePhase === PHASES[PHASES.length - 1].id ? "#334155" : "#94a3b8",
                cursor: activePhase === PHASES[PHASES.length - 1].id ? "not-allowed" : "pointer",
                fontSize: 11,
              }}
            >
              Next phase →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
