# FORM 1023 PART IV — PROGRAM NARRATIVE DRAFT
## Secure Pride, Inc.
### "Past, Present, and Planned Activities" — The Most Important Section

---

> **INSTRUCTIONS:** This is the make-or-break section of Form 1023. The IRS
> needs to understand exactly what you do, who you serve, and how it is
> charitable/educational. Be specific. Be concrete. Avoid vague mission-statement
> language. Sections marked [INSERT] require real data before filing.
>
> Word budget: no formal limit, but 3–6 pages of narrative is typical for
> a small technical nonprofit. Quality over length.

---

## Part IV — Narrative Description of Your Activities

### A. Overview

Secure Pride, Inc. is a nonprofit cybersecurity organization founded in Durham,
North Carolina, dedicated to providing culturally competent digital security
resources to LGBTQ+ community organizations, health clinics, small businesses,
and other community-serving entities with limited technical capacity and
resources.

The organization addresses a documented and urgent gap: LGBTQ+-serving
organizations routinely handle extraordinarily sensitive data — including
sexual orientation and gender identity (SOGI) information, HIV status, mental
health records, and immigration status — yet consistently lack access to the
security expertise, tools, and training that would protect their clients from
data breaches, surveillance, and targeted cyberattacks. A breach of this data
is not merely a compliance failure; for many clients of LGBTQ+ organizations,
exposure of their SOGI data can result in discrimination, family rejection,
violence, or legal consequences in hostile jurisdictions.

Secure Pride addresses this problem through three core program areas:
(1) direct technical assistance and security assessments, (2) open-source
tool development, and (3) cybersecurity education and capacity building.

---

### B. Past and Present Activities

> **[INSERT ACTUAL ACTIVITIES YOU'VE DONE — use real examples]**
> Examples below are illustrative templates. Replace with specifics.

**Security Consulting and Technical Assistance**

Since its founding in [YEAR], Secure Pride has provided direct cybersecurity
assistance to [X] organizations in the Research Triangle region of North
Carolina. Engagements have included:

- Security assessments of [TYPE OF ORGANIZATION] identifying [X] critical
  vulnerabilities and providing remediation roadmaps;
- Configuration of encrypted communication tools for [ORGANIZATION TYPE] staff
  handling sensitive client intake information;
- Incident response guidance for [X] organizations that experienced or suspected
  data breaches;
- Privacy architecture reviews for digital intake forms collecting SOGI data.

[INSERT: Any specific organizations you've worked with, with their permission.
Generic descriptions ("a Durham-based LGBTQ+ health clinic") are acceptable if
you prefer not to name organizations.]

**Tool Development**

Secure Pride has developed and maintains [DESCRIBE TOOLS — e.g., "a lightweight
security audit framework designed for non-technical executive directors, enabling
organizations to self-assess their basic security posture without requiring IT
staff"]. All tools are open-source and freely available on GitHub under
[LICENSE TYPE].

**Education and Community Outreach**

Secure Pride has conducted [X] educational workshops and presentations,
reaching [X] attendees including [describe audience]. Topics have included:

- Basic digital hygiene and phishing awareness for nonprofit staff;
- SOGI data protection obligations under HIPAA, state law, and funder requirements;
- Secure communication practices for organizations operating in high-risk environments;
- Introduction to privacy-by-design principles for program staff building intake systems.

[INSERT specific events, dates, attendance counts as available]

---

### C. Planned Activities

**Program Area 1 — Direct Technical Assistance (Year 1–2)**

Secure Pride will expand its direct technical assistance program to serve a
minimum of [X] organizations per year in [GEOGRAPHIC AREA]. Services will include:

*Security Assessments:* Structured 2–4 hour assessments of organizational
security posture, covering device security, account access controls, data handling
practices, incident response readiness, and vendor risk. Assessments produce a
written report with prioritized, actionable recommendations tailored to the
organization's capacity and budget.

*Implementation Support:* Follow-on support helping organizations implement
security improvements identified in assessments. This may include configuring
multi-factor authentication, implementing encrypted storage solutions, establishing
data retention and deletion policies, and training staff on secure practices.

*Incident Response:* Emergency support for organizations experiencing security
incidents, including data breach triage, containment guidance, notification
support, and post-incident recovery.

*Who is served:* Organizations will be prioritized based on: (a) LGBTQ+-serving
mission, (b) limited IT capacity (no full-time IT staff), and (c) sensitivity
of data handled. Services will be provided at no cost to qualifying organizations.
Larger organizations with capacity to pay may be charged on a sliding-scale basis,
with any revenue reinvested in free services for smaller organizations.

**Program Area 2 — Open-Source Tool Development (Year 1–3)**

Secure Pride will develop and maintain a suite of open-source security tools
specifically designed for community organizations. Tools will be designed with
the following principles:

- *Accessibility:* Usable by non-technical staff. No command-line required for
  standard use cases. WCAG 2.1 AA accessible interfaces.
- *Cultural competency:* Terminology, examples, and threat models reflect
  LGBTQ+ organizational contexts.
- *Privacy-first architecture:* No telemetry. Minimal data collection. Local
  processing where possible.
- *Open source:* All code published on GitHub under [LICENSE]. Community
  contributions welcomed.

Tools in development include:
[INSERT specific tools — e.g., "a security policy template generator for
nonprofits," "a self-guided privacy impact assessment tool," etc.]

All tools will be documented in plain language for non-technical users and
accompanied by implementation guides.

**Program Area 3 — Education and Capacity Building (Year 1–3)**

Secure Pride will develop and deliver a structured cybersecurity education
curriculum for LGBTQ+ organizations, including:

*Foundational Security Workshop:* A 2-hour introductory workshop covering
essential security hygiene for nonprofit staff. Available as in-person, virtual,
and self-paced online formats. Free to attend.

*Executive Director Briefing:* A 90-minute session designed for organizational
leadership, covering governance responsibilities for data protection, key
regulatory obligations, and how to make the case for security investment
internally.

*SOGI Data Protection Intensive:* A half-day workshop for organizations
collecting sensitive SOGI data, covering applicable legal frameworks, technical
controls, policy requirements, and incident response obligations.

All curriculum materials will be published under Creative Commons licensing
for free use by other trainers and organizations.

**Program Area 4 — Research and Documentation**

Secure Pride will conduct and publish research on the cybersecurity threat
landscape facing LGBTQ+ organizations, including:

- Documenting known breaches affecting LGBTQ+-serving organizations and their
  impacts;
- Developing threat models specific to LGBTQ+ organizational contexts;
- Surveying organizational security posture across the LGBTQ+ nonprofit sector
  to identify systemic gaps and priorities.

Research will be published under open-access terms and made available to
policymakers, funders, and peer organizations.

---

### D. Who We Serve and How We Identify Them

Secure Pride's primary beneficiaries are:

1. **LGBTQ+ community organizations** — advocacy organizations, community
   centers, support groups, legal services organizations;
2. **LGBTQ+-affirming health clinics** — including HIV/AIDS service organizations,
   sexual health clinics, and mental health providers serving LGBTQ+ populations;
3. **LGBTQ+-owned small businesses** — particularly those handling sensitive
   client data;
4. **Organizations serving LGBTQ+ youth** — after-school programs, shelters,
   and support organizations.

We identify organizations through:
- Community partnerships and referrals from LGBTQ+ community networks in the
  Research Triangle region (Durham, Chapel Hill, Raleigh);
- Outreach at LGBTQ+ community convenings and nonprofit conferences;
- Inbound requests via our website and community networks;
- Partnerships with fiscal sponsors and other capacity-building organizations.

Geographic scope in Years 1–2: Research Triangle / Durham, NC metro area.
Geographic scope in Year 3+: Statewide NC expansion; national tool and
curriculum distribution via open-source channels.

---

### E. Qualifications

Secure Pride's leadership brings the following qualifications to this work:

[INSERT: Mazze's relevant background — UC Davis Regents Scholar, quantitative
psychology / cognitive neuroscience, security research experience at major
central banks, cybersecurity research background — described in organizational
terms, not as a biography. E.g.:]

The organization's founder and Executive Director holds a Bachelor of Science
in Quantitative Psychology and Cognitive Neuroscience from the University of
California, Davis (Regents Scholar), with graduate-level research experience in
neural network modeling and statistical analysis. They have conducted
cybersecurity research for major financial institutions and bring extensive
experience in security tool development, privacy architecture, and community
education. [ADD ANY CERTIFICATIONS, ADVISORY BOARD MEMBERS, PARTNER ORGS]

---

### F. How Activities Accomplish Exempt Purposes

All of Secure Pride's activities accomplish charitable and educational purposes
under Section 501(c)(3) in the following ways:

*Charitable:* Direct technical assistance to LGBTQ+ organizations is charitable
because it (a) serves a recognized class of persons facing discrimination and
heightened vulnerability to harm from data breaches, (b) provides expert services
that recipient organizations could not otherwise afford, and (c) protects the
health, safety, and civil rights of the individuals served by those organizations.

*Educational:* Workshops, curriculum, and published research disseminate
knowledge about cybersecurity to community organizations and the general public,
advancing security literacy and organizational capacity.

*Relieving burdens of government:* By helping organizations protect sensitive
personal data, Secure Pride reduces the incidence of data breaches that impose
costs on individuals, organizations, and government agencies responsible for
enforcement.

No private shareholders or individuals will benefit from these activities
beyond reasonable compensation for services rendered. All tools and curriculum
are provided free of charge or at cost to qualifying organizations.

---

## CHECKLIST BEFORE FILING

- [ ] Replace all [INSERT] placeholders with real, specific information
- [ ] Add actual organizations served (with permission, or describe generically)
- [ ] Add actual attendance/engagement numbers from past activities
- [ ] List specific tools in development with brief descriptions
- [ ] Have at least one person unfamiliar with your work read it for clarity
- [ ] Review against IRS Publication 557 for exempt purposes language
- [ ] Confirm narrative aligns with Articles of Incorporation purpose clause

---

*This narrative draft is for planning purposes. It does not constitute legal
advice. Consult with a nonprofit attorney before filing Form 1023 if possible.*
