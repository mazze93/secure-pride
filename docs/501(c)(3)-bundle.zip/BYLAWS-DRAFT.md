# BYLAWS — DRAFT
## Secure Pride, Inc.
### A North Carolina Nonprofit Corporation
### DRAFT — Adopt at organizational board meeting before IRS filing

---

> **STATUS:** Working draft. These bylaws must be adopted by formal board
> resolution at the organizational meeting and attached to Form 1023.
> Sections marked [INSERT] require your decisions before adoption.

---

## BYLAWS OF SECURE PRIDE, INC.

---

### ARTICLE I — NAME AND PURPOSES

**Section 1.01 — Name.**
The name of this corporation is Secure Pride, Inc. (the "Corporation").

**Section 1.02 — Purposes.**
The Corporation is organized and shall be operated exclusively for charitable
and educational purposes within the meaning of Section 501(c)(3) of the
Internal Revenue Code of 1986, as amended, as more fully described in the
Corporation's Articles of Incorporation.

**Section 1.03 — Nonprofit Status.**
The Corporation is a nonprofit corporation organized under Chapter 55A of the
North Carolina General Statutes. No part of the net earnings of the Corporation
shall inure to the benefit of any director, officer, or private individual.

---

### ARTICLE II — OFFICES

**Section 2.01 — Principal Office.**
The Corporation's principal office shall be located in Durham, North Carolina,
or at such other location as the Board of Directors may determine.

**Section 2.02 — Registered Office and Agent.**
The Corporation shall maintain a registered office and registered agent in
North Carolina as required by law. The Board may change the registered agent
or office by filing the appropriate form with the NC Secretary of State.

---

### ARTICLE III — BOARD OF DIRECTORS

**Section 3.01 — Powers.**
The Board of Directors (the "Board") shall manage and direct the affairs of the
Corporation and shall exercise all powers authorized by law and the Articles of
Incorporation, unless otherwise delegated by these Bylaws.

**Section 3.02 — Number of Directors.**
The Board shall consist of no fewer than **three (3)** and no more than
**[INSERT: 7 or 9]** directors. The exact number may be fixed by resolution of
the Board within this range.

> **NOTE:** The IRS requires at least 3 unrelated directors for 501(c)(3)
> credibility. Odd numbers prevent voting ties. 5 or 7 is common for startups.

**Section 3.03 — Qualifications.**
Directors must be at least 18 years of age. No more than 49% of directors may
be related to each other by blood, marriage, or business relationship (i.e.,
must be "independent"). Directors need not be residents of North Carolina.

**Section 3.04 — Election and Terms.**
Directors shall serve staggered two-year terms. At the first organizational
meeting, [half / one-third] of directors shall be elected to one-year terms
and the remainder to two-year terms, to establish stagger. Thereafter, all
newly elected directors shall serve two-year terms. Directors may serve
up to [INSERT: 3 or unlimited] consecutive terms.

**Section 3.05 — Initial Board.**
The initial Board of Directors shall consist of the following persons:

1. [DIRECTOR 1 FULL LEGAL NAME], [Title if any], [City, State]
2. [DIRECTOR 2 FULL LEGAL NAME], [Title if any], [City, State]
3. [DIRECTOR 3 FULL LEGAL NAME], [Title if any], [City, State]
   *(add more as needed)*

**Section 3.06 — Vacancies.**
A vacancy on the Board shall be filled by majority vote of the remaining
directors for the unexpired portion of the term.

**Section 3.07 — Removal.**
A director may be removed with or without cause by a two-thirds (2/3) vote of
the entire Board at any duly called meeting at which a quorum is present,
provided that notice of the intended removal is given in the meeting notice.

**Section 3.08 — Resignation.**
A director may resign at any time by submitting written notice to the Board
Chair or Secretary. Resignation is effective upon receipt unless a later date
is specified.

**Section 3.09 — Compensation.**
Directors shall serve without compensation for their service as directors,
unless the Board adopts a compensation policy by resolution. Directors may be
reimbursed for reasonable, documented expenses incurred on behalf of the
Corporation.

---

### ARTICLE IV — MEETINGS OF THE BOARD

**Section 4.01 — Regular Meetings.**
The Board shall hold at least [INSERT: 4 or 6] regular meetings per year.
Meeting dates and locations shall be set by the Board Chair at the beginning
of each fiscal year.

**Section 4.02 — Special Meetings.**
Special meetings may be called by the Board Chair or by petition of any two
directors, upon at least five (5) days' written notice stating the purpose
of the meeting.

**Section 4.03 — Notice.**
Notice of regular and special meetings may be delivered by email, mail, or
other written means. Attendance at a meeting constitutes waiver of notice,
unless the director attends solely to object to the meeting's lack of proper
notice.

**Section 4.04 — Quorum.**
A majority of directors then serving shall constitute a quorum for the
transaction of business. No business may be conducted without a quorum.

**Section 4.05 — Voting.**
Each director is entitled to one vote. Actions require approval by a majority
of directors present at a meeting at which a quorum exists, unless a greater
vote is required by law, the Articles, or these Bylaws.

**Section 4.06 — Action Without Meeting.**
The Board may take action without a meeting if all directors consent to such
action in writing (including by email). Written consents shall be filed with
the corporate records and shall have the same force as a vote at a meeting.

**Section 4.07 — Remote Participation.**
Directors may participate in meetings by video or teleconference with the same
rights and voting privileges as if physically present, provided a quorum
participates and all participants can hear and be heard simultaneously.

---

### ARTICLE V — OFFICERS

**Section 5.01 — Officers.**
The officers of the Corporation shall be:
- President (or Executive Director)
- Secretary
- Treasurer

The Board may elect additional officers as needed. One person may hold two
offices, except that the President and Secretary may not be the same person.

**Section 5.02 — Election and Terms.**
Officers shall be elected by the Board at the annual meeting and shall serve
one-year terms, until their successors are elected or until earlier resignation,
removal, or death. Officers may be re-elected without limit.

**Section 5.03 — President / Executive Director.**
The President (or Executive Director, if the roles are separated) shall be the
chief executive officer of the Corporation; shall preside at all Board meetings;
shall execute contracts and instruments on behalf of the Corporation as
authorized by the Board; and shall perform such other duties as the Board
may assign.

**Section 5.04 — Secretary.**
The Secretary shall maintain minutes of all Board meetings and actions; shall
give notice of meetings; shall maintain the corporate records; and shall
authenticate records of the Corporation.

**Section 5.05 — Treasurer.**
The Treasurer shall be responsible for overseeing the fiscal affairs of the
Corporation; shall ensure that appropriate financial records are maintained;
shall present financial reports at each regular Board meeting; and shall
oversee the preparation of annual financial statements and tax filings.

**Section 5.06 — Removal of Officers.**
Any officer may be removed with or without cause by majority vote of the Board.

---

### ARTICLE VI — COMMITTEES

**Section 6.01 — Authorization.**
The Board may establish standing or ad hoc committees by resolution. Committees
shall have only such authority as the Board delegates by resolution. No committee
may (a) amend the Articles or Bylaws, (b) adopt a plan of dissolution, or
(c) approve actions requiring Board approval under applicable law.

**Section 6.02 — Initial Committees.**
The following committees are authorized:

- **Finance Committee:** Oversees budgeting, financial controls, and audit.
  Minimum 2 members including the Treasurer.
- **Program Committee:** Oversees programmatic activities and evaluation.
- **Governance Committee:** Oversees board recruitment, orientation, and
  self-evaluation.

---

### ARTICLE VII — FINANCIAL MANAGEMENT

**Section 7.01 — Fiscal Year.**
The fiscal year of the Corporation shall be the calendar year (January 1 –
December 31), unless changed by Board resolution.

**Section 7.02 — Budget.**
The Board shall adopt an annual operating budget before or at the start of each
fiscal year. Material deviations from the approved budget require Board approval.

**Section 7.03 — Banking.**
The Board shall designate one or more financial institutions for the deposit of
corporate funds. Checks or withdrawals above **$[INSERT: 500 or 1,000]** shall
require the signature of two authorized officers or directors.

**Section 7.04 — Contracts and Expenditures.**
The Executive Director (or President) is authorized to enter into contracts
and expenditures up to **$[INSERT: 2,500 or 5,000]** without prior Board approval.
Amounts above this threshold require Board approval.

**Section 7.05 — Audit and Review.**
When the Corporation's annual revenues exceed **$[INSERT: $100,000 or $250,000]**,
the Board shall arrange for an independent financial review or audit.

---

### ARTICLE VIII — INDEMNIFICATION

**Section 8.01 — Indemnification of Directors and Officers.**
To the fullest extent permitted by Chapter 55A of the North Carolina General
Statutes, the Corporation shall indemnify any director or officer who is made
a party to any proceeding by reason of service to the Corporation.

**Section 8.02 — Insurance.**
The Board may purchase directors' and officers' (D&O) liability insurance to
protect directors and officers from claims arising from their service.

---

### ARTICLE IX — CONFLICT OF INTEREST

**Section 9.01 — Policy.**
The Corporation shall maintain a written Conflict of Interest Policy. All
directors and officers shall review and sign the Policy annually.

**Section 9.02 — Disclosure.**
Any director or officer with a material financial interest in a proposed
transaction involving the Corporation shall: (a) promptly disclose the interest
to the Board, (b) recuse themselves from deliberation and voting on the matter,
and (c) not be counted toward quorum for that vote.

---

### ARTICLE X — RECORDS AND REPORTS

**Section 10.01 — Corporate Records.**
The Corporation shall maintain: Articles of Incorporation and all amendments;
Bylaws and all amendments; Board meeting minutes; annual financial statements;
and copies of all Form 990 filings for at least 7 years.

**Section 10.02 — Public Inspection.**
The Corporation shall make available for public inspection its Form 990,
Form 1023 application (as filed), and Articles of Incorporation, as required
by law.

---

### ARTICLE XI — AMENDMENTS

**Section 11.01 — Amendment of Bylaws.**
These Bylaws may be amended by a two-thirds (2/3) vote of the entire Board
at any duly noticed meeting, provided that the text of the proposed amendment
is included in the meeting notice. No amendment may conflict with the Articles
of Incorporation or applicable law.

---

### ARTICLE XII — DISSOLUTION

**Section 12.01 — Dissolution.**
The Corporation may be dissolved only by a two-thirds (2/3) vote of the entire
Board, followed by the procedures required by Chapter 55A of the North Carolina
General Statutes. Upon dissolution, assets shall be distributed as specified
in the Articles of Incorporation.

---

## CERTIFICATION OF ADOPTION

These Bylaws were duly adopted by the initial Board of Directors of Secure Pride,
Inc. at its organizational meeting held on:

**Date:** ____________________

**Location:** ____________________

**Board Chair Signature:** ____________________

**Printed Name:** ____________________

**Secretary Signature:** ____________________

**Printed Name:** ____________________

---

## PRE-ADOPTION CHECKLIST

- [ ] Number of directors decided and inserted (Sections 3.02, 3.05)
- [ ] Director term limit decided and inserted (Section 3.04)
- [ ] Regular meeting frequency decided (Section 4.01)
- [ ] Spending thresholds decided (Sections 7.03, 7.04, 7.05)
- [ ] Fiscal year confirmed (calendar year recommended for simplicity)
- [ ] Initial directors listed with full legal names (Section 3.05)
- [ ] Initial officers elected at board meeting
- [ ] Board meeting minutes recorded and retained
- [ ] COI Policy adopted alongside these Bylaws

---

*This draft is for planning purposes and does not constitute legal advice.
NC Pro Bono Resource Center (ncprobono.org) may offer free nonprofit legal assistance.*
