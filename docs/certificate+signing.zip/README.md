# Secure Pride — Certificate & Signing Setup
## Complete guide for email signing, git commits, macOS, PyPI, npm

---

## Quick start — run in order

```bash
# 1. Install dependencies (if needed)
brew install gnupg pinentry-mac

# 2. Generate GPG key (covers git, PGP email, PyPI, npm)
bash 01-setup-gpg.sh

# 3. Wire GPG to git, npm, PyPI CI workflows
bash 02-configure-signing.sh

# 4. Back up primary key to offline storage — DO THIS IMMEDIATELY
bash 03-backup-keys.sh

# 5. Get free S/MIME cert for Apple Mail / Outlook / Thunderbird
open SMIME-SETUP.md

# 6. Set up Apple Developer ID for macOS binary notarization
open APPLE-NOTARIZATION.md
```

---

## Architecture overview

```
Your Signing Identity
├── GPG Key (Ed25519 primary, certify-only)
│   ├── Subkey: Sign     → git commits, PGP email
│   ├── Subkey: Encrypt  → encrypted email (PGP)
│   └── Subkey: Auth     → SSH (via gpg-agent)
│
├── Sigstore / OIDC (via GitHub Actions)
│   ├── npm publish --provenance    → npm provenance
│   └── pypa/gh-action-pypi-publish → PyPI Trusted Publisher
│
├── S/MIME Certificate (Actalis, free, 1yr)
│   └── Email signing: Apple Mail, Outlook, Thunderbird
│
└── Apple Developer ID (Apple Developer Program, $99/yr)
    ├── codesign → binary signing
    └── notarytool → Apple notarization + stapling
```

---

## What each tool covers

| Use case | Tool | CA / Source | Cost |
|----------|------|-------------|------|
| Git commit signing | GPG (Ed25519) | Self-generated | Free |
| PGP email (Thunderbird, Proton) | GPG (Ed25519) | keys.openpgp.org | Free |
| S/MIME email (Apple Mail, Outlook) | S/MIME cert | Actalis | Free |
| npm package signing | Sigstore (OIDC) | GitHub Actions | Free |
| PyPI package signing | Sigstore (Trusted Publisher) | GitHub Actions | Free |
| macOS binary signing | Developer ID cert | Apple | $99/yr |
| macOS notarization | Apple notarytool | Apple | incl. above |

---

## CA recommendations rationale

- **Actalis** for S/MIME: Only major CA offering a fully free 1-year cert with
  broad mail client support. SSL.com's free tier expires in 90 days and has
  more friction. DigiCert and Sectigo are overkill (and expensive) for
  individual signing.

- **keys.openpgp.org** for GPG keyserver: Privacy-respecting (no unauthenticated
  email harvesting), well-maintained, widely supported.

- **Sigstore** for npm/PyPI: Both registries are moving to OIDC-based provenance.
  PyPI deprecated GPG upload support in 2023. Sigstore is the future-proof choice
  and requires zero cert management.

- **Apple Developer Program** for macOS: No alternative. Any redistributed macOS
  binary must be notarized by Apple or users face Gatekeeper blocks.

---

## Key security model

```
┌──────────────────────────────────────────────────────┐
│  OFFLINE (USB / hardware token)                      │
│  ┌─────────────────────────────────────────────┐     │
│  │  GPG Primary Key (certify-only)             │     │
│  │  Revocation certificate                     │     │
│  │  S/MIME backup (.p12)                       │     │
│  └─────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────┐
│  ONLINE (macOS Keychain, daily use)                  │
│  ┌─────────────────────────────────────────────┐     │
│  │  GPG Subkeys (sign, encrypt, auth)          │     │
│  │  S/MIME cert (Actalis)                      │     │
│  │  Apple Developer ID cert                    │     │
│  └─────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────┐
│  CI/CD (GitHub Secrets — ephemeral)                  │
│  ┌─────────────────────────────────────────────┐     │
│  │  GPG subkey export (for CI git signing)     │     │
│  │  Apple Developer ID cert (base64)           │     │
│  │  npm token, Apple ID app-specific password  │     │
│  └─────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────┘
```

---

## Renewal schedule

| Cert | Expires | Reminder |
|------|---------|----------|
| GPG key | 2 years | Set calendar event now |
| GPG subkeys | 2 years | Set calendar event now |
| Actalis S/MIME | 1 year | Set calendar event now |
| Apple Developer Program | 1 year | Apple emails 30 days before |

---

## Files in this package

```
01-setup-gpg.sh         GPG key generation + gpg-agent config
02-configure-signing.sh Wire GPG to git, npm CI, PyPI CI
03-backup-keys.sh       Encrypted offline key backup
SMIME-SETUP.md          Actalis S/MIME cert walkthrough
APPLE-NOTARIZATION.md   Apple Developer ID + notarytool guide
README.md               This file
```

---

## Testing checklist

- [ ] `git commit --allow-empty -m "test: gpg signing"` — check for `gpg: Good signature` in `git log --show-signature`
- [ ] `gpg --verify` on a test-signed file
- [ ] Send a signed email from Apple Mail to a Gmail account — recipient should see the signature badge
- [ ] Check npm provenance: `npm audit signatures` after a test publish
- [ ] Verify PyPI package: `pip install sigstore && sigstore verify github ./dist/*.whl`
- [ ] macOS binary: `spctl --assess --verbose YourApp.app` → `accepted`
- [ ] Backup restore drill: decrypt `gpg-backup.tar.gz.enc` and confirm keys import cleanly
