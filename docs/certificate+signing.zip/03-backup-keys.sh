#!/usr/bin/env bash
# =============================================================================
# 03-backup-keys.sh — Encrypted Offline Backup of GPG Primary Key
# =============================================================================
# Creates an AES-256-encrypted archive of your primary key and revocation cert.
# Store the output on an OFFLINE device (USB drive, hardware token, etc.).
# NEVER store your primary key backup in cloud storage or version control.
#
# Usage:  bash 03-backup-keys.sh [OUTPUT_DIR]
# Default output dir: ~/gpg-backup-YYYY-MM-DD (on Desktop)
# =============================================================================

set -euo pipefail
IFS=$'\n\t'

# ── Color helpers ─────────────────────────────────────────────────────────────
tty_reset=""  tty_green=""  tty_yellow=""  tty_bold=""  tty_red=""
if [ -t 1 ]; then
  tty_reset="\033[0m"; tty_green="\033[32m"
  tty_yellow="\033[33m"; tty_bold="\033[1m"; tty_red="\033[31m"
fi
info()  { printf "${tty_green}[INFO]${tty_reset}  %s\n" "$*"; }
warn()  { printf "${tty_yellow}[WARN]${tty_reset}  %s\n" "$*"; }
err()   { printf "${tty_red}[ERROR]${tty_reset} %s\n" "$*" >&2; }
die()   { err "$*"; exit 1; }
section() { printf "\n${tty_bold}▸ %s${tty_reset}\n" "$*"; }

# ── Variables ─────────────────────────────────────────────────────────────────
TIMESTAMP=$(date +%Y-%m-%d)
OUTPUT_DIR="${1:-$HOME/Desktop/gpg-backup-${TIMESTAMP}}"
TEMP_DIR=$(mktemp -d)
ARCHIVE_NAME="gpg-primary-backup-${TIMESTAMP}.tar.gz"
ENCRYPTED_NAME="${ARCHIVE_NAME}.enc"

# ── Cleanup on exit ───────────────────────────────────────────────────────────
cleanup() {
  if [[ -d "$TEMP_DIR" ]]; then
    # Securely wipe temp files before removal
    find "$TEMP_DIR" -type f -exec \
      sh -c 'dd if=/dev/urandom of="$1" bs=1k count=$(( ($(wc -c < "$1") + 1023) / 1024 )) conv=notrunc 2>/dev/null; rm -f "$1"' _ {} \;
    rm -rf "$TEMP_DIR"
    info "Temp files securely wiped"
  fi
}
trap cleanup EXIT

# ── Resolve signing key ───────────────────────────────────────────────────────
resolve_primary_key() {
  section "Selecting key to back up"

  local keys_found
  keys_found=$(gpg --list-secret-keys --with-colons 2>/dev/null \
    | awk -F: '/^sec/{print $5}' | wc -l | tr -d ' ')

  [[ "$keys_found" -gt 0 ]] || die "No GPG secret keys found."

  if [[ "$keys_found" -eq 1 ]]; then
    GPG_FPR=$(gpg --list-secret-keys --with-colons 2>/dev/null \
      | awk -F: '/^fpr/{print $10; exit}')
    info "Auto-detected key fingerprint: ${GPG_FPR}"
  else
    gpg --list-secret-keys --keyid-format=long
    printf "\nEnter the fingerprint of the PRIMARY key to back up: "
    read -r GPG_FPR
    [[ -n "$GPG_FPR" ]] || die "Fingerprint required"
  fi

  export GPG_FPR
}

# ── Export key material to temp dir ──────────────────────────────────────────
export_key_material() {
  section "Exporting key material"

  # Primary secret key (certify-only)
  gpg --armor --export-secret-keys "${GPG_FPR}" \
    > "${TEMP_DIR}/secret-primary-key.asc"
  info "  ✓ Secret primary key exported"

  # Secret subkeys (sign, encrypt, auth)
  gpg --armor --export-secret-subkeys "${GPG_FPR}" \
    > "${TEMP_DIR}/secret-subkeys.asc"
  info "  ✓ Secret subkeys exported"

  # Public key
  gpg --armor --export "${GPG_FPR}" \
    > "${TEMP_DIR}/public-key.asc"
  info "  ✓ Public key exported"

  # Revocation certificate
  # --gen-revoke creates an interactive flow; use --command-fd to automate
  gpg --batch --gen-revoke "${GPG_FPR}" <<EOF > "${TEMP_DIR}/revocation-cert.asc" 2>/dev/null
y
1
Key material compromised - pre-generated revocation cert
y
EOF
  info "  ✓ Revocation certificate generated"

  # Key info summary (human-readable)
  gpg --list-secret-keys --keyid-format=long "${GPG_FPR}" \
    > "${TEMP_DIR}/key-info.txt"
  printf "Backed up: %s\nTimestamp: %s\n" "${GPG_FPR}" "$(date -u)" \
    >> "${TEMP_DIR}/key-info.txt"
  info "  ✓ Key info summary written"
}

# ── Archive and encrypt ───────────────────────────────────────────────────────
encrypt_backup() {
  section "Creating encrypted archive"

  # Create tar archive in temp dir
  local archive_path="${TEMP_DIR}/${ARCHIVE_NAME}"
  tar -czf "${archive_path}" -C "${TEMP_DIR}" \
    secret-primary-key.asc \
    secret-subkeys.asc \
    public-key.asc \
    revocation-cert.asc \
    key-info.txt

  info "Archive created"

  # Encrypt with AES-256-GCM via GPG symmetric encryption
  # Uses a passphrase — WRITE THIS DOWN AND STORE SEPARATELY from the backup
  warn "You will be prompted to set an ENCRYPTION PASSPHRASE."
  warn "Store this passphrase separately from the backup file (e.g., printed paper)."

  gpg --symmetric \
    --cipher-algo AES256 \
    --s2k-mode 3 \
    --s2k-count 65011712 \
    --s2k-digest-algo SHA512 \
    --armor \
    --output "${TEMP_DIR}/${ENCRYPTED_NAME}" \
    "${archive_path}"

  info "Archive encrypted with AES-256 + PBKDF2/SHA-512"

  # Move to output dir
  mkdir -p "${OUTPUT_DIR}"
  chmod 700 "${OUTPUT_DIR}"
  mv "${TEMP_DIR}/${ENCRYPTED_NAME}" "${OUTPUT_DIR}/${ENCRYPTED_NAME}"
  info "Encrypted backup saved to: ${OUTPUT_DIR}/${ENCRYPTED_NAME}"
}

# ── Verify the backup can be decrypted ───────────────────────────────────────
verify_backup() {
  section "Verifying backup integrity"

  local verify_dir
  verify_dir=$(mktemp -d)

  # Attempt to list the archive contents (decrypt + extract to /dev/null)
  if gpg --decrypt "${OUTPUT_DIR}/${ENCRYPTED_NAME}" 2>/dev/null \
      | tar -tz --wildcards 'secret-primary-key.asc' >/dev/null 2>&1; then
    info "  ✓ Backup verified — archive decrypts and contains expected files"
  else
    warn "  ! Verification failed or passphrase not entered. Please verify manually:"
    warn "    gpg --decrypt ${OUTPUT_DIR}/${ENCRYPTED_NAME} | tar -tz"
  fi

  rm -rf "${verify_dir}"
}

# ── Print next steps ──────────────────────────────────────────────────────────
print_next_steps() {
  section "Backup complete"

  printf "${tty_bold}Backup location:${tty_reset} %s/%s\n\n" \
    "${OUTPUT_DIR}" "${ENCRYPTED_NAME}"

  printf "${tty_bold}CRITICAL — do all of these:${tty_reset}\n"
  printf "  1. Copy %s to an OFFLINE USB drive or hardware token\n" "${ENCRYPTED_NAME}"
  printf "  2. Write your encryption passphrase on paper — store SEPARATELY from USB\n"
  printf "  3. Store a second copy offsite (e.g., safe deposit box)\n"
  printf "  4. DO NOT upload this file to Dropbox, iCloud, Google Drive, or any cloud\n"
  printf "  5. Delete %s from your Desktop after copying to offline storage\n\n" "${ENCRYPTED_NAME}"

  printf "${tty_bold}To restore from backup:${tty_reset}\n"
  printf "  gpg --decrypt %s | tar -xz\n" "${ENCRYPTED_NAME}"
  printf "  gpg --import secret-primary-key.asc\n"
  printf "  gpg --import secret-subkeys.asc\n\n"
}

# ── Main ──────────────────────────────────────────────────────────────────────
main() {
  info "Starting GPG key backup"
  resolve_primary_key
  export_key_material
  encrypt_backup
  verify_backup
  print_next_steps
}

main "$@"
