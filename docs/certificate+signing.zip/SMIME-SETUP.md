# SMIME-SETUP.md — Free S/MIME Certificate via Actalis
## For Secure Pride email signing (Apple Mail + Outlook + Thunderbird)

---

## Why Actalis?

| CA | Cost | Validity | Mail Clients | Notes |
|----|------|----------|--------------|-------|
| **Actalis** | Free | 1 year | All major | Easiest free option, widely trusted |
| SSL.com | Free tier | 90 days | Most | More limited free tier |
| DigiCert | $$$  | 1–3 years | All | Best for enterprise |

Actalis issues a free Class 1 S/MIME cert (email-validated only) that works
in Apple Mail, Outlook, Thunderbird, iOS Mail, and Android Gmail.

---

## Step 1 — Request your Actalis S/MIME cert

1. Go to: https://www.actalis.com/s-mime-certificates.aspx
2. Click **"Free S/MIME Certificate"**
3. Enter the email address you want to sign with
4. Complete the CAPTCHA and submit
5. Check that email inbox — Actalis sends a download link within minutes

> **Privacy note:** Actalis will embed your email address in the cert's Subject
> Alternative Name (SAN) field. This is standard and required for mail client
> compatibility. No other PII is stored.

---

## Step 2 — Download and extract the cert

Actalis sends a `.zip` containing:
- `Certificate.p12` or `Certificate.pfx` — your cert + private key bundle
- A temporary password (emailed separately, or shown on screen)

```bash
# Unzip in a secure location
mkdir -p ~/smime-certs
chmod 700 ~/smime-certs
unzip ~/Downloads/actalis-smime.zip -d ~/smime-certs
```

---

## Step 3 — Import into Keychain (macOS)

```bash
# Import the .p12 into your login keychain
# You'll be prompted for:
#   1. The Actalis-provided .p12 password
#   2. Your macOS login password (to allow keychain access)
security import ~/smime-certs/Certificate.p12 \
  -k ~/Library/Keychains/login.keychain-db \
  -T /Applications/Mail.app \
  -T /Applications/Microsoft\ Outlook.app
```

Or double-click `Certificate.p12` in Finder → Keychain Access opens automatically.

> **After import:** Set the trust level for the Actalis root CA if prompted.
> Select "Always Trust" for S/MIME.

---

## Step 4 — Enable signing in Apple Mail

1. Open **Mail → Settings → Accounts**
2. Select your account → **Advanced**
3. Under **S/MIME**, enable **Sign** (and optionally **Encrypt**)
4. Select your Actalis certificate from the dropdown
5. Send a test signed email to yourself

---

## Step 5 — Enable signing in Thunderbird

1. **Account Settings → End-To-End Encryption**
2. Under **S/MIME**, click **Manage Certificates**
3. Import → select `Certificate.p12` → enter Actalis password
4. Set as default signing certificate
5. Compose a message → check **Security → Digitally Sign This Message**

---

## Step 6 — Enable signing in Outlook (macOS)

1. **Outlook → Settings → Accounts → [your account] → Advanced**
2. Under **Security**, select your certificate from the **Signing Certificate** dropdown
3. Check **Send signed messages**

---

## Renewal

Actalis free certs expire after **1 year**. Set a calendar reminder to renew.
The process is identical — request a new cert, re-import.

---

## Exporting a backup

```bash
# Export your S/MIME cert + key as encrypted .p12 for backup
# Store this alongside your GPG backup on your offline USB
security export \
  -k ~/Library/Keychains/login.keychain-db \
  -t identities \
  -f pkcs12 \
  -o ~/smime-certs/smime-backup.p12
```

You'll be prompted to set a new export password. Store it separately from the file.

---

## Privacy audit

- [x] No PII beyond email address collected by Actalis
- [x] Private key generated locally — Actalis never sees it (PKCS#12 model)
- [x] Cert stored in macOS Keychain (AES-256 encrypted at rest)
- [x] Backup export protected by user-set passphrase
- [x] No telemetry or tracking in S/MIME signing workflow
