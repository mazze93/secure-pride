# APPLE-NOTARIZATION.md — macOS Code Signing & Notarization
## For Secure Pride binary distribution

---

## Overview

macOS requires two things for distributable binaries:
1. **Developer ID Code Signing** — proves the binary came from you
2. **Apple Notarization** — Apple scans the binary for malware and stamps it

Without both, macOS Gatekeeper blocks your binary with "unidentified developer."

**Cost:** Apple Developer Program = $99/year (USD)
**Link:** https://developer.apple.com/programs/enroll/

> For nonprofits: Apple does not offer free enrollment, but the $99 covers
> unlimited signing certs, TestFlight, and App Store distribution.

---

## Step 1 — Enroll in Apple Developer Program

1. Go to https://developer.apple.com/account
2. Enroll as an **Individual** (Mazze) or **Organization** (Secure Pride, requires DUNS number)
3. Pay $99/yr — takes 24–48 hours for activation

---

## Step 2 — Create a Developer ID Application certificate

In Xcode or via the web portal:

### Via Xcode (easiest):
1. **Xcode → Settings → Accounts**
2. Add your Apple ID
3. **Manage Certificates → +**
4. Select **Developer ID Application**
5. Xcode generates the key pair and installs the cert in Keychain automatically

### Via CLI (automation-friendly):
```bash
# List available signing identities
security find-identity -v -p codesigning

# Output will look like:
# 1) ABCDEF1234... "Developer ID Application: Your Name (TEAMID)"
```

---

## Step 3 — Sign a binary

```bash
# ── Variables ──────────────────────────────────────────────────────────────
APP_PATH="./dist/YourApp.app"   # or path to binary
BUNDLE_ID="org.securepride.yourapp"
TEAM_ID="YOUR10CHAR"            # found at developer.apple.com/account
SIGNING_IDENTITY="Developer ID Application: Your Name (${TEAM_ID})"
ENTITLEMENTS="./entitlements.plist"   # optional, but required for some features

# ── Sign the binary ────────────────────────────────────────────────────────
codesign \
  --sign "${SIGNING_IDENTITY}" \
  --options runtime \
  --entitlements "${ENTITLEMENTS}" \
  --timestamp \
  --deep \
  --verbose \
  "${APP_PATH}"

# ── Verify signature ───────────────────────────────────────────────────────
codesign --verify --deep --strict --verbose=2 "${APP_PATH}"
spctl --assess --verbose "${APP_PATH}"
```

**Minimum entitlements.plist** (required for notarization with Hardened Runtime):
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <!-- Hardened Runtime: disable only what you actually need -->
  <key>com.apple.security.cs.allow-jit</key>         <false/>
  <key>com.apple.security.cs.allow-dyld-environment-variables</key> <false/>
</dict>
</plist>
```

---

## Step 4 — Notarize

Apple notarization uses `notarytool` (replaces the deprecated `altool`).

### Store credentials in Keychain (one-time setup):
```bash
xcrun notarytool store-credentials "notarytool-profile" \
  --apple-id "your@email.com" \
  --team-id "${TEAM_ID}" \
  --password "xxxx-xxxx-xxxx-xxxx"  # App-specific password from appleid.apple.com
```

### Submit for notarization:
```bash
# Zip the .app first (notarytool requires a zip, dmg, or pkg)
ditto -c -k --keepParent "${APP_PATH}" "${APP_PATH%.app}.zip"

# Submit
xcrun notarytool submit "${APP_PATH%.app}.zip" \
  --keychain-profile "notarytool-profile" \
  --wait

# On success you'll see: status: Accepted
```

### Staple the notarization ticket:
```bash
# Stapling embeds the ticket so Gatekeeper works offline
xcrun stapler staple "${APP_PATH}"
xcrun stapler validate "${APP_PATH}"
```

---

## Step 5 — GitHub Actions CI/CD (automated signing)

```yaml
# .github/workflows/macos-release.yml
name: macOS Build & Notarize

on:
  push:
    tags: ['v*']

jobs:
  build-and-notarize:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v4

      - name: Import Developer ID certificate
        env:
          CERT_P12_BASE64: ${{ secrets.MACOS_CERT_P12 }}
          CERT_PASSWORD: ${{ secrets.MACOS_CERT_PASSWORD }}
        run: |
          echo "$CERT_P12_BASE64" | base64 --decode > /tmp/cert.p12
          security create-keychain -p "" build.keychain
          security import /tmp/cert.p12 -k build.keychain \
            -P "$CERT_PASSWORD" -T /usr/bin/codesign
          security list-keychains -s build.keychain
          security default-keychain -s build.keychain
          security unlock-keychain -p "" build.keychain
          security set-keychain-settings -t 3600 -u build.keychain
          rm /tmp/cert.p12

      - name: Build app
        run: make build   # replace with your actual build command

      - name: Sign binary
        env:
          SIGNING_IDENTITY: ${{ secrets.MACOS_SIGNING_IDENTITY }}
        run: |
          codesign --sign "$SIGNING_IDENTITY" \
            --options runtime --timestamp --deep --verbose \
            ./dist/YourApp.app

      - name: Notarize
        env:
          APPLE_ID: ${{ secrets.APPLE_ID }}
          APPLE_TEAM_ID: ${{ secrets.APPLE_TEAM_ID }}
          APPLE_APP_PASSWORD: ${{ secrets.APPLE_APP_PASSWORD }}
        run: |
          ditto -c -k --keepParent ./dist/YourApp.app ./dist/YourApp.zip
          xcrun notarytool submit ./dist/YourApp.zip \
            --apple-id "$APPLE_ID" \
            --team-id "$APPLE_TEAM_ID" \
            --password "$APPLE_APP_PASSWORD" \
            --wait
          xcrun stapler staple ./dist/YourApp.app
```

### Required GitHub Secrets:
| Secret | Value |
|--------|-------|
| `MACOS_CERT_P12` | Base64-encoded Developer ID cert: `base64 -i cert.p12` |
| `MACOS_CERT_PASSWORD` | .p12 export password |
| `MACOS_SIGNING_IDENTITY` | `Developer ID Application: Name (TEAMID)` |
| `APPLE_ID` | Your Apple ID email |
| `APPLE_TEAM_ID` | 10-char team ID |
| `APPLE_APP_PASSWORD` | App-specific password from appleid.apple.com |

---

## Privacy audit

- [x] Signing certificate and private key stored in macOS Keychain (AES-256)
- [x] CI uses ephemeral keychains (deleted after build)
- [x] Secrets injected via GitHub Secrets (never in source)
- [x] notarytool uploads binary to Apple for scanning — this is Apple's privacy policy
- [x] No user PII involved in signing workflow

---

## Interim Option — Local Signing Without Apple Developer Program
### Use until 501(c)(3) approval + Apple fee waiver is granted

### Option A — Ad-hoc signature (no Apple account needed)

```bash
# Sign with ad-hoc identity — no Developer ID, no Apple account
codesign --sign - --options runtime --deep --verbose ./dist/YourApp.app

# Verify
codesign --verify --deep --verbose=2 ./dist/YourApp.app
```

Gives you: binary integrity / tamper detection, runs on YOUR machine.
Does NOT give: Gatekeeper trust on other Macs, notarization.

Recipients on other Macs can open your app by right-clicking → Open → "Open Anyway",
or via terminal (one-time, per app, does NOT disable Gatekeeper globally):

```bash
xattr -d com.apple.quarantine /Applications/YourApp.app
```

### Option B — Xcode Personal Team (free Apple ID, no $99)

```bash
# List identities including free Personal Team
security find-identity -v -p codesigning

# Sign with Personal Team identity
codesign --sign "Apple Development: your@email.com (XXXXXXXXXX)" \
  --deep --verbose ./dist/YourApp.app
```

Limitations: 7-day expiry on test devices, max 3 devices, no distribution.

### Ship binaries safely without Developer ID

```bash
# Zip the app (not dmg)
zip -r YourApp.zip YourApp.app

# Generate SHA-256 checksum for recipients to verify
shasum -a 256 YourApp.zip > YourApp.zip.sha256
cat YourApp.zip.sha256
```

Include the checksum in your release notes. Recipients verify with:
`shasum -a 256 -c YourApp.zip.sha256`

### Timeline

Once Secure Pride receives its IRS 501(c)(3) determination letter, apply for
the Apple Developer Program fee waiver (details at developer.apple.com).
Approval typically takes 1–2 weeks. Then generate a Developer ID cert and
re-sign all distributed binaries with full notarization.
