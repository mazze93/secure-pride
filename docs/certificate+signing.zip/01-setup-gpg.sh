#!/usr/bin/env bash
# =============================================================================
# 01-setup-gpg.sh — GPG Key Generation for Secure Pride
# =============================================================================
# Generates a hardened Ed25519 primary key (certify-only, offline-safe) with
# three subkeys: sign, encrypt, authenticate. Covers: git commits, PGP email,
# PyPI, npm, and SSH auth (bonus).
#
# Usage:  bash 01-setup-gpg.sh
# Requires: gnupg ≥2.3, pinentry-mac (brew install gnupg pinentry-mac)
# Platform: macOS ARM (M-series)
# =============================================================================

set -euo pipefail
IFS=$'\n\t'

# ── Constants ─────────────────────────────────────────────────────────────────
readonly KEYSERVER="hkps://keys.openpgp.org"
readonly GPG_VERSION_MIN="2.3"
readonly PINENTRY_PATH="/opt/homebrew/bin/pinentry-mac"  # ARM Homebrew path
readonly EXPIRY="2y"

# ── Color helpers (skip if not a TTY) ────────────────────────────────────────
tty_bold=""  tty_reset=""  tty_green=""  tty_yellow=""  tty_red=""
if [ -t 1 ]; then
  tty_bold="\033[1m"; tty_reset="\033[0m"
  tty_green="\033[32m"; tty_yellow="\033[33m"; tty_red="\033[31m"
fi
info()    { printf "${tty_green}[INFO]${tty_reset}  %s\n" "$*"; }
warn()    { printf "${tty_yellow}[WARN]${tty_reset}  %s\n" "$*"; }
err()     { printf "${tty_red}[ERROR]${tty_reset} %s\n" "$*" >&2; }
die()     { err "$*"; exit 1; }
section() { printf "\n${tty_bold}▸ %s${tty_reset}\n" "$*"; }

# ── Pre-flight checks ─────────────────────────────────────────────────────────
check_dependencies() {
  section "Checking dependencies"
  command -v gpg >/dev/null 2>&1 || die "gpg not found. Run: brew install gnupg"
  command -v brew >/dev/null 2>&1 || die "Homebrew not found. Install from https://brew.sh"

  local gpg_ver
  gpg_ver=$(gpg --version | head -1 | awk '{print $3}')
  info "GPG version: $gpg_ver"

  if ! brew list pinentry-mac &>/dev/null; then
    warn "pinentry-mac not installed. Installing now..."
    brew install pinentry-mac
  fi
  info "pinentry-mac: OK"
}

# ── Configure GPG agent to use pinentry-mac ───────────────────────────────────
configure_gpg_agent() {
  section "Configuring GPG agent"
  local agent_conf="$HOME/.gnupg/gpg-agent.conf"
  mkdir -p "$HOME/.gnupg"
  chmod 700 "$HOME/.gnupg"

  # Write agent config (idempotent — overwrite known values)
  cat > "$agent_conf" <<EOF
pinentry-program ${PINENTRY_PATH}
default-cache-ttl 600
max-cache-ttl 7200
enable-ssh-support
EOF

  info "GPG agent configured at $agent_conf"
  gpgconf --kill gpg-agent 2>/dev/null || true
  info "GPG agent restarted"
}

# ── Collect key metadata ──────────────────────────────────────────────────────
collect_key_metadata() {
  section "Key metadata"
  printf "Full name (for key UID): "
  read -r GPG_NAME
  printf "Email address:           "
  read -r GPG_EMAIL
  printf "Comment (optional, e.g. 'Secure Pride signing key'): "
  read -r GPG_COMMENT

  [[ -n "$GPG_NAME" ]]  || die "Name is required"
  [[ -n "$GPG_EMAIL" ]] || die "Email is required"

  export GPG_NAME GPG_EMAIL GPG_COMMENT
  info "UID will be: ${GPG_NAME} (${GPG_COMMENT}) <${GPG_EMAIL}>"
}

# ── Generate primary key (certify-only) ───────────────────────────────────────
# The primary key never leaves your machine (ideally goes to offline storage).
# All day-to-day operations use subkeys.
generate_primary_key() {
  section "Generating primary Ed25519 key (certify-only)"

  # Use --batch mode for reproducible parameters
  local uid_string
  if [[ -n "$GPG_COMMENT" ]]; then
    uid_string="${GPG_NAME} (${GPG_COMMENT}) <${GPG_EMAIL}>"
  else
    uid_string="${GPG_NAME} <${GPG_EMAIL}>"
  fi

  gpg --batch --gen-key <<EOF
%no-protection
Key-Type: EDDSA
Key-Curve: ed25519
Key-Usage: cert
Name-Real: ${GPG_NAME}
Name-Comment: ${GPG_COMMENT}
Name-Email: ${GPG_EMAIL}
Expire-Date: ${EXPIRY}
%commit
EOF

  # Retrieve the fingerprint of the just-created key
  GPG_FPR=$(gpg --with-colons --fingerprint "${GPG_EMAIL}" \
    | awk -F: '/^fpr/{print $10; exit}')
  export GPG_FPR
  info "Primary key fingerprint: ${GPG_FPR}"
}

# ── Add subkeys (sign, encrypt, authenticate) ─────────────────────────────────
add_subkeys() {
  section "Adding subkeys"

  # Sign subkey  — Ed25519
  # Encrypt subkey — Cv25519 (Curve25519 ECDH)
  # Auth subkey — Ed25519 (enables SSH via gpg-agent)
  gpg --batch --pinentry-mode loopback --command-fd 0 \
      --expert --edit-key "${GPG_FPR}" <<EOF
addkey
10
q
save
EOF
  # NOTE: The interactive batch above is tricky; use a helper function per subkey.
  # More reliable: add subkeys with explicit calls
  _add_subkey_sign
  _add_subkey_encrypt
  _add_subkey_auth

  info "Subkeys added"
}

_add_subkey_sign() {
  gpg --batch --pinentry-mode loopback --quick-add-key \
    "${GPG_FPR}" ed25519 sign "${EXPIRY}"
  info "  ✓ Signing subkey (ed25519)"
}

_add_subkey_encrypt() {
  gpg --batch --pinentry-mode loopback --quick-add-key \
    "${GPG_FPR}" cv25519 encr "${EXPIRY}"
  info "  ✓ Encryption subkey (cv25519)"
}

_add_subkey_auth() {
  gpg --batch --pinentry-mode loopback --quick-add-key \
    "${GPG_FPR}" ed25519 auth "${EXPIRY}"
  info "  ✓ Authentication subkey (ed25519, SSH-ready)"
}

# ── Export public key ─────────────────────────────────────────────────────────
export_and_publish_key() {
  section "Exporting public key"
  local export_dir="$HOME/.gnupg/exports"
  mkdir -p "$export_dir"
  chmod 700 "$export_dir"

  gpg --armor --export "${GPG_FPR}" > "${export_dir}/public-key.asc"
  info "Public key exported to: ${export_dir}/public-key.asc"

  printf "\nUpload to keys.openpgp.org? (recommended) [y/N]: "
  read -r upload_confirm
  if [[ "${upload_confirm,,}" == "y" ]]; then
    gpg --keyserver "${KEYSERVER}" --send-keys "${GPG_FPR}"
    info "Key uploaded to ${KEYSERVER}"
    info "Check your email to verify ownership at keys.openpgp.org"
  else
    warn "Skipped upload. Upload manually: gpg --keyserver ${KEYSERVER} --send-keys ${GPG_FPR}"
  fi
}

# ── Print summary ─────────────────────────────────────────────────────────────
print_summary() {
  section "Summary"
  gpg --list-secret-keys --keyid-format=long "${GPG_FPR}"
  printf "\n${tty_bold}Your key fingerprint:${tty_reset} %s\n" "${GPG_FPR}"
  printf "${tty_bold}Next steps:${tty_reset}\n"
  printf "  1. Run 02-configure-signing.sh to wire git, npm, PyPI\n"
  printf "  2. Run 03-backup-keys.sh IMMEDIATELY to back up your primary key\n"
  printf "  3. Follow SMIME-SETUP.md for email signing cert (Actalis)\n"
  printf "  4. Follow APPLE-NOTARIZATION.md for macOS code signing\n\n"
}

# ── Main ──────────────────────────────────────────────────────────────────────
main() {
  info "Starting Secure Pride GPG key setup"
  check_dependencies
  configure_gpg_agent
  collect_key_metadata
  generate_primary_key
  add_subkeys
  export_and_publish_key
  print_summary
}

main "$@"
