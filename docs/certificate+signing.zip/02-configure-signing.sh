#!/usr/bin/env bash
# =============================================================================
# 02-configure-signing.sh — Wire GPG to git, npm, and PyPI
# =============================================================================
# Run AFTER 01-setup-gpg.sh. Configures:
#   - git:  auto-sign all commits and tags
#   - npm:  GPG signing + Sigstore provenance (GitHub Actions)
#   - PyPI: GPG signing + Sigstore (via gh-action-sigstore-python)
#
# Usage:  bash 02-configure-signing.sh
# =============================================================================

set -euo pipefail
IFS=$'\n\t'

# ── Color helpers ─────────────────────────────────────────────────────────────
tty_reset=""  tty_green=""  tty_yellow=""  tty_bold=""  tty_red=""
if [ -t 1 ]; then
  tty_reset="\033[0m"; tty_green="\033[32m"
  tty_yellow="\033[33m"; tty_bold="\033[1m"; tty_red="\033[31m"
fi
info()    { printf "${tty_green}[INFO]${tty_reset}  %s\n" "$*"; }
warn()    { printf "${tty_yellow}[WARN]${tty_reset}  %s\n" "$*"; }
section() { printf "\n${tty_bold}▸ %s${tty_reset}\n" "$*"; }
die()     { printf "${tty_red}[ERROR]${tty_reset} %s\n" "$*" >&2; exit 1; }

# ── Resolve signing key ───────────────────────────────────────────────────────
resolve_signing_key() {
  section "Detecting signing key"

  # Try to find the key by user input or auto-detect single key
  local keys_found
  keys_found=$(gpg --list-secret-keys --with-colons 2>/dev/null \
    | awk -F: '/^sec/{print $5}' | wc -l | tr -d ' ')

  if [[ "$keys_found" -eq 0 ]]; then
    die "No GPG secret keys found. Run 01-setup-gpg.sh first."
  fi

  if [[ "$keys_found" -eq 1 ]]; then
    SIGNING_KEY=$(gpg --list-secret-keys --with-colons 2>/dev/null \
      | awk -F: '/^sec/{print $5}' | head -1)
    info "Auto-detected signing key: ${SIGNING_KEY}"
  else
    info "Multiple keys found:"
    gpg --list-secret-keys --keyid-format=long
    printf "\nEnter the Key ID to use for signing (long format, e.g. ABCD1234EFGH5678): "
    read -r SIGNING_KEY
    [[ -n "$SIGNING_KEY" ]] || die "Key ID required"
  fi

  export SIGNING_KEY
}

# ── Configure git ─────────────────────────────────────────────────────────────
configure_git() {
  section "Configuring git commit and tag signing"

  git config --global user.signingkey "${SIGNING_KEY}"
  git config --global commit.gpgsign true
  git config --global tag.gpgsign true

  # Point git to the correct gpg binary (Homebrew ARM path)
  local gpg_bin
  gpg_bin=$(command -v gpg)
  git config --global gpg.program "${gpg_bin}"

  info "git config set:"
  info "  user.signingkey = ${SIGNING_KEY}"
  info "  commit.gpgsign  = true"
  info "  tag.gpgsign     = true"
  info "  gpg.program     = ${gpg_bin}"

  info "Test with: git commit --allow-empty -m 'test: verify gpg signing'"
}

# ── Configure npm ─────────────────────────────────────────────────────────────
# npm does not natively support GPG signing of packages (only the registry token
# is used for auth). Modern npm supports Sigstore provenance instead.
# We configure:
#   1. npm provenance via GitHub Actions (Sigstore) — recommended
#   2. A .npmrc stub for your publishing workflow
configure_npm() {
  section "Configuring npm"
  command -v npm >/dev/null 2>&1 || { warn "npm not found, skipping"; return; }

  # Enforce HTTPS registry and strict SSL
  npm config set registry "https://registry.npmjs.org/"
  npm config set strict-ssl true

  info "npm registry set to https://registry.npmjs.org/ with strict SSL"

  # Write GitHub Actions workflow for provenance-signed npm publish
  local workflow_dir=".github/workflows"
  mkdir -p "${workflow_dir}"

  cat > "${workflow_dir}/npm-publish.yml" <<'YAML'
# ── npm publish with Sigstore provenance ─────────────────────────────────────
# This workflow publishes to npm and attaches a Sigstore provenance statement,
# verifiable with: npm audit signatures
name: Publish to npm

on:
  push:
    tags: ['v*']

permissions:
  contents: read
  id-token: write   # Required for Sigstore OIDC provenance

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          registry-url: 'https://registry.npmjs.org'

      - name: Install dependencies
        run: npm ci

      - name: Run tests
        run: npm test

      - name: Publish with provenance
        run: npm publish --provenance --access public
        env:
          NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}
YAML

  info "npm provenance workflow written to ${workflow_dir}/npm-publish.yml"
  warn "Add NPM_TOKEN to your GitHub repo secrets before using"
}

# ── Configure PyPI ────────────────────────────────────────────────────────────
# PyPI deprecated GPG signatures in 2023. The modern standard is Sigstore
# via Trusted Publishers (OIDC). We configure both paths.
configure_pypi() {
  section "Configuring PyPI"

  # Write GitHub Actions workflow for PyPI Trusted Publisher (Sigstore)
  local workflow_dir=".github/workflows"
  mkdir -p "${workflow_dir}"

  cat > "${workflow_dir}/pypi-publish.yml" <<'YAML'
# ── PyPI publish with Sigstore (Trusted Publisher) ────────────────────────────
# Uses PyPI Trusted Publishers (OIDC) — no API token needed.
# Provenance is automatically attached via Sigstore.
# Setup: https://docs.pypi.org/trusted-publishers/adding-a-publisher/
name: Publish to PyPI

on:
  push:
    tags: ['v*']

permissions:
  contents: read
  id-token: write   # Required for OIDC Trusted Publisher

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Install build tools
        run: pip install build

      - name: Build distribution
        run: python -m build

      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: dist
          path: dist/

  publish:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: pypi
      url: https://pypi.org/p/${{ github.event.repository.name }}
    steps:
      - uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/

      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
        # No password needed — Trusted Publisher uses OIDC
YAML

  info "PyPI Trusted Publisher workflow written to ${workflow_dir}/pypi-publish.yml"
  warn "Register your repo as a Trusted Publisher at: https://pypi.org/manage/account/publishing/"

  # Also write a pyproject.toml snippet as reference
  cat > "pyproject.signing.toml.example" <<'TOML'
# Add this to your pyproject.toml — Sigstore signs automatically via the
# GitHub Actions workflow above. No manual GPG signing required.
[tool.hatch.build]
# Hatch picks up Sigstore provenance from OIDC automatically

[project.urls]
"Source" = "https://github.com/mazze93/your-package"
TOML

  info "Example pyproject.toml snippet written to pyproject.signing.toml.example"
}

# ── Shell environment: GPG_TTY ────────────────────────────────────────────────
# Without GPG_TTY, pinentry can't find the terminal for passphrase prompts.
configure_shell_env() {
  section "Configuring shell environment"

  local shell_rc
  case "${SHELL}" in
    */zsh)  shell_rc="$HOME/.zshrc"  ;;
    */bash) shell_rc="$HOME/.bashrc" ;;
    *)      shell_rc="$HOME/.profile" ;;
  esac

  local gpg_env_block
  gpg_env_block=$(cat <<'EOF'

# ── GPG signing (added by 02-configure-signing.sh) ───────────────────────────
export GPG_TTY=$(tty)
# Ensure ssh uses gpg-agent for auth subkey
export SSH_AUTH_SOCK=$(gpgconf --list-dirs agent-ssh-socket)
gpgconf --launch gpg-agent 2>/dev/null || true
EOF
)

  # Idempotent: only add if not already present
  if ! grep -q "GPG_TTY" "${shell_rc}" 2>/dev/null; then
    printf "%s\n" "${gpg_env_block}" >> "${shell_rc}"
    info "Added GPG_TTY export to ${shell_rc}"
  else
    info "GPG_TTY already configured in ${shell_rc}"
  fi
}

# ── Summary ───────────────────────────────────────────────────────────────────
print_summary() {
  section "All done"
  printf "${tty_bold}Signing configured:${tty_reset}\n"
  printf "  ✓ git:  all commits and tags auto-signed with key %s\n" "${SIGNING_KEY}"
  printf "  ✓ npm:  Sigstore provenance workflow at .github/workflows/npm-publish.yml\n"
  printf "  ✓ PyPI: Trusted Publisher workflow at .github/workflows/pypi-publish.yml\n"
  printf "\n${tty_bold}Remaining manual steps:${tty_reset}\n"
  printf "  1. Source your shell rc:  source ~/.zshrc\n"
  printf "  2. Run 03-backup-keys.sh to secure your primary key\n"
  printf "  3. Follow SMIME-SETUP.md for Actalis S/MIME cert\n"
  printf "  4. Follow APPLE-NOTARIZATION.md for Developer ID cert\n\n"
}

# ── Main ──────────────────────────────────────────────────────────────────────
main() {
  resolve_signing_key
  configure_git
  configure_npm
  configure_pypi
  configure_shell_env
  print_summary
}

main "$@"
