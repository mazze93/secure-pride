# Docker Hub CI Token Workflow Pack (mazze93)

This pack scripts a hardened “Docker Hub PAT for CI” workflow:

- Create a **dedicated CI token** (Read/Write, **no Delete**) with an expiration
- Store it in **GitHub Actions secrets**
- Use it from a **release workflow** that pushes images **only on tags**
- Optional: **monthly reminder** to rotate tokens

## What you get

- `.github/workflows/release.yml` — buildx build + push on version tags
- `.github/workflows/token-reminder.yml` — monthly reminder to rotate
- `bin/gh-secrets-setup.sh` — sets `DOCKERHUB_USERNAME` + `DOCKERHUB_TOKEN` via `gh`
- `bin/dockerhub-login-test.sh` — sanity-check login locally
- `bin/repo-init.sh` — drop workflows into an existing repo (idempotent)
- `docs/DOCKERHUB_TOKEN_WORKFLOW.md` — step-by-step playbook

## Quick start (existing repo)

1) Copy this pack into your repo root.
2) Run:

```bash
./bin/repo-init.sh
```

3) Create a Docker Hub token:
   - Docker Hub → Settings → Personal access tokens → Generate new token
   - **Scope:** Read, Write
   - **Expiration:** 90 days (recommended)
   - Copy the token (shown once)

4) Save secrets to GitHub (requires GitHub CLI `gh` logged in):

```bash
export DOCKERHUB_TOKEN="paste-token-here"
./bin/gh-secrets-setup.sh
```

5) Tag + push a release:

```bash
git tag -a v0.1.0 -m "v0.1.0"
git push origin v0.1.0
```

The workflow will build and push:

- `docker.io/mazze93/<IMAGE_NAME>:v0.1.0`
- `docker.io/mazze93/<IMAGE_NAME>:latest` (optional toggle)

## Customize

Edit `.github/workflows/release.yml`:

- `IMAGE_NAME` (defaults to the repo name)
- `REGISTRY` (defaults to docker.io)
- toggle `PUSH_LATEST`

## Notes

- This pack intentionally avoids **Delete scope**.
- Prefer 90-day expirations and rotate.
