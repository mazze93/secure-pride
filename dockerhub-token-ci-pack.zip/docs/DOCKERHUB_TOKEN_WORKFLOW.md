# Docker Hub PAT → GitHub Actions CI Publishing Workflow (Hardened)

This is the minimal, sane way to publish Docker images without “who pushed what from where” chaos.

## 1) Token discipline

Create a dedicated token for CI:

- Description: `github-ci-<repo>` (example: `github-ci-secure-container`)
- Scope: **Read, Write**
- Avoid: **Delete** (CI almost never needs it)
- Expiration: **90 days** (recommended)

Keep Docker Desktop auto-generated tokens for local CLI convenience, but prune stale ones.

## 2) GitHub secrets

Secrets required:

- `DOCKERHUB_USERNAME` = `mazze93`
- `DOCKERHUB_TOKEN` = your PAT

Use the included helper:

```bash
export DOCKERHUB_TOKEN="paste-token-here"
./bin/gh-secrets-setup.sh
```

Requirements:

- `gh` installed
- `gh auth login` already done
- run inside the repo you want to configure

## 3) Release-only publishing

Publishing should happen on tags, not on every push.

This pack uses:

- tags matching `v*.*.*` (e.g., `v1.2.3`)

On tag push, the workflow:

- logs into Docker Hub
- builds with `buildx`
- pushes a versioned tag
- optionally pushes `latest`

## 4) Rotation reminder

`token-reminder.yml` runs monthly and opens an issue reminding you to rotate.

If you don’t want it, delete that workflow.

## 5) Common failure modes

- **401 / denied**: token was copied incorrectly, or is expired
- **no tags triggered**: your tag didn’t match `v*.*.*`
- **image name wrong**: adjust `IMAGE_NAME` in the workflow
